//
//  Pokemon.swift
//  MasterDex
//
//  Created by Emmanuel on 08/02/24.
//

import Foundation

struct PokemonPage: Codable{
    let count: Int?
    let next: String?
    let previous: String?
    let results: [Pokemon]
}

struct Pokemon: Codable,Identifiable, Equatable {
    let id = UUID()
    let name: String
    let url: String

    static var samplePoke = Pokemon(name: "bulbasaur", url: "https://pokeapi.co/api/v2/pokemon/1/")
    
}

struct DetailPokemon: Codable {
    let id: Int?
    let height: Int
    let weight: Int
//    let stats: [Stats]
//    let type: [Types]
}

struct Stats: Codable {
    let hp: Int
    let attack: Int
    let defense: Int
    let specialAttack: Int
    let specialDefense: Int
    let speed: Int
    
    enum CodingKeys: String, CodingKey{
        case hp = "0"
        case attack = "1"
        case defense = "2"
        case specialAttack = "3"
        case specialDefense = "4"
        case speed = "5"
    }
}

struct Types: Codable{
    let id: Int
}
