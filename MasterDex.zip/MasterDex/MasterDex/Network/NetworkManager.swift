//
//  NetworkManager.swift
//  MasterDex
//
//  Created by Emmanuel on 08/02/24.
//

import Foundation

extension Bundle{
    static let allPokesURL = "https://pokeapi.co/api/v2/pokemon/?offset=0&limit=1025"
    
    func decodeLocalJSON<T:Codable>(file:String) -> T{
        guard let url = self.url(forResource: file, withExtension: nil) else { fatalError("\(file) not find") }
        guard let data = try? Data(contentsOf: url) else { fatalError("\(file) error") }
        
        do {
            let popo = try JSONDecoder().decode(T.self, from: data)
            return popo
        } catch {
            print("||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
            print("Error en el json no se puede porque :\(error)")
            
//            fatalError("no jalo porque el \(file) no esta jando el perro")
        }
        
        guard let pokeData = try? JSONDecoder().decode(T.self, from: data) else { fatalError("\(file) not decode") }
        
        
        return pokeData
    }
    
    func fetchData<T:Decodable>(url: String, model: T.Type, completion:@escaping(T) -> (), failure:@escaping(Error) -> ()){
        guard let url = URL(string: url) else { return  }
        
        URLSession.shared.dataTask(with: url){ data, response, error in
            
            guard let data = data else{
                if let error = error {
                    failure(error)
                }
                return
            }
            do {
                let serverData = try JSONDecoder().decode(T.self, from: data)
                completion(serverData)
            } catch {
                failure(error)
            }
            
        }.resume()
        
    }
    
}

//class NetworkManager {
//    static let singleton = NetworkManager()
//    static let allPokesURL = "https://pokeapi.co/api/v2/pokemon/?offset=0&limit=1025"
//
//    init() {}
//    func getPokeList(completed: @escaping (Result<[Pokemon], ApiError>) -> Void){
//        guard let url = URL(string: NetworkManager.allPokesURL) else{
//            completed(.failure(.invalidURL))
//            return
//        }
//
//        let urlSession = URLSession.shared.dataTask(with: url){ data, _, error in
//            if let _ = error{
//                completed(.failure(.unableToComprete))
//                return
//            }
//
//            guard let data = data else{
//                    completed(.failure(.decodingError))
//                    return
//                }
//                do {
//                    let decoder = JSONDecoder()
//                    let decodedResponse = try decoder.decode([Pokemon].self, from: data as Data)
//                    completed(.success(decodedResponse))
//                } catch {
//                    print("error \(error.localizedDescription)")
//                    completed(.failure(.decodingError))
//                }
//
//        }
//        urlSession.resume()
//    }
//
//}
