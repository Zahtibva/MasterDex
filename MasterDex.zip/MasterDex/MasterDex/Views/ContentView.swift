//
//  ContentView.swift
//  MasterDex
//
//  Created by Emmanuel on 08/02/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = PokemonViewModel()
    @State private var isActive = false
    
    private let adaptativeColums = [
        GridItem(.adaptive(minimum: 380))
    ]
    var body: some View {
        
        VStack{
         
            NavigationView{
                VStack{
                    ScrollView{
                        LazyVGrid(columns: adaptativeColums, spacing: 10){
                            
                            ForEach(viewModel.filteredPokemon){ pokemon in
                                NavigationLink(destination: PokemonDetailsView(pokemon: pokemon)){
                                    PokemonCell(pokemon: pokemon)
                                }
                            }
                            .animation(.easeOut(duration: 0.3), value: viewModel.filteredPokemon.count)
                            .navigationTitle("MasterDex")
                            .navigationBarTitleDisplayMode(.inline)
                        }
                        .searchable(text: $viewModel.searchPoke)

                    }

                    NavigationLink(destination: PokemonDetailsView(pokemon: viewModel.filteredPokemon.randomElement()!)){
        //                PokemonCell(pokemon: viewModel.filteredPokemon.randomElement()!)
                        Text("**Mostrar Pokemón**")
                    }.frame(width: 380, height: 50)
                        .background(.red)
                        .cornerRadius(10)
                        .foregroundColor(.white)
                        .font(.title)
                }

                
            }.environmentObject(viewModel)

            
            
            
//            Button("**Mostrar Pokemón**"){
//                let randomNum = Int.random(in: 1..<1026)
//                print(randomNum)
//                guard let rand = viewModel.filteredPokemon.randomElement() else { return }
////                let rand = viewModel.filteredPokemon.randomElement()
//                print(rand)
//                isActive = true
//
//
//            }.frame(width: 380, height: 50)
//                .background(.red)
//                .cornerRadius(10)
//                .foregroundColor(.white)
//                .font(.title)
//
//            NavigationLink(destination: PokemonDetailsView(pokemon: viewModel.filteredPokemon.randomElement()!)){
////                PokemonCell(pokemon: viewModel.filteredPokemon.randomElement()!)
//                Text("**Mostrar Pokemón**")
//            }.frame(width: 380, height: 50)
//                .background(.red)
//                .cornerRadius(10)
//                .foregroundColor(.white)
//                .font(.title)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
