//
//  MasterDexApp.swift
//  MasterDex
//
//  Created by Emmanuel on 08/02/24.
//

import SwiftUI

@main
struct MasterDexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
