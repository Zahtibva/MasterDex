//
//  SwiftUIView.swift
//  MasterDex
//
//  Created by Emmanuel on 09/02/24.
//

import SwiftUI

struct PokemonCell: View {
    
    @EnvironmentObject var viewModel: PokemonViewModel
    let pokemon: Pokemon
    let cellHeight: Double = 140
    let cellWeight: Double = 380
    
    var body: some View {
        VStack{
            HStack{//}(spacing: 120){

                AsyncImage(url: URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/\( viewModel.getPokemonIndex(pokemon:pokemon)).png")){ image in
                    if let image = image {
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(width: cellHeight, height: cellHeight)
                    }
                } placeholder: {
                    ProgressView()
                        .frame(width: cellHeight, height: cellHeight)
                }

                Spacer()
                
                .frame(width: 0)
                Text("\(pokemon.name.capitalized)")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading)
                    .font(.largeTitle)
                    .foregroundColor(.black)

            }
            
        }
        .frame(width: cellWeight, height: cellHeight + 20)
        .background(.thinMaterial)
            .cornerRadius(10)
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        PokemonCell( pokemon: Pokemon.samplePoke)
            .environmentObject(PokemonViewModel())
    }
}
