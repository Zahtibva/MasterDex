//
//  PokemonCoordinator.swift
//  MasterDex
//
//  Created by Emmanuel on 09/02/24.
//

import Foundation

class PokemonCoordinator {
//    static let allPokesURL = "https://pokeapi.co/api/v2/pokemon/?offset=0&limit=1025"
    func getPoke()->[Pokemon]{
        let data: PokemonPage = Bundle.main.decodeLocalJSON(file: "pokemon.json")// no funciono obteniendo los datos directamente desde la api
        let pokemon: [Pokemon] = data.results
        
        return pokemon
    }
    
    func getPokeDetails(id: Int,_ completion:@escaping (DetailPokemon) -> ()){
        Bundle.main.fetchData(url: "https://pokeapi.co/api/v2/pokemon/\(id)/", model: DetailPokemon.self){ data in
            
            completion(data)
            
        }failure: { error in
            print(error.localizedDescription)
        }
    }
    
}
