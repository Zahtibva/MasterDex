//
//  PokemonDetailsView.swift
//  MasterDex
//
//  Created by Emmanuel on 09/02/24.
//

import SwiftUI

struct PokemonDetailsView: View {
    @EnvironmentObject var viewModel: PokemonViewModel
    let pokemon: Pokemon
    
    var body: some View {
        VStack{
            PokemonCell(pokemon: pokemon)

            VStack(alignment: .leading, spacing: 10){
                Text("ID: \(viewModel.pokemonDetails?.id ?? 00)")
                Text("height: \(viewModel.formatHW(value: viewModel.pokemonDetails?.height ?? 0)) Metros")
                Text("weight: \(viewModel.formatHW(value: viewModel.pokemonDetails?.weight ?? 0)) Kg")
//                Text("stats: \(viewModel.pokemonDetails?.stats)")
            }
            .frame(alignment: .leading)
        }
        .onAppear(){
            viewModel.getDetails(pokemon: pokemon)

        }
        
        
    }
    
    
    
}

struct PokemonDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        PokemonDetailsView(pokemon: Pokemon.samplePoke)
            .environmentObject(PokemonViewModel())
    }
}
