//
//  PokemonViewModel.swift
//  MasterDex
//
//  Created by Emmanuel on 09/02/24.
//

import Foundation
import SwiftUI

class PokemonViewModel: ObservableObject{
    private let coordinator = PokemonCoordinator()
    
    @Published var pokemonList = [Pokemon]()
    @Published var pokemonDetails: DetailPokemon?
    @Published var searchPoke = ""
    
    var filteredPokemon: [Pokemon]{
        return searchPoke == "" ? pokemonList : pokemonList.filter{
            $0.name.contains(searchPoke.lowercased())
        }
    }
    
    init (){
        self.pokemonList = coordinator.getPoke()
    }
    
    func getPokemonIndex(pokemon: Pokemon) -> Int{
        if let index = self.pokemonList.firstIndex(of: pokemon){
            return index + 1
        }
        return 0
    }
    
    func getDetails(pokemon: Pokemon){
        let id = getPokemonIndex(pokemon: pokemon)
        
        self.pokemonDetails = DetailPokemon(id: 0, height: 0, weight: 0)//, stats: [Stats(hp: 0, attack: 0, defense: 0, specialAttack: 0, specialDefense: 0, speed: 0)])//, type: <#T##[Types]#>)
        
        coordinator.getPokeDetails(id: id) { data in
            
            DispatchQueue.main.async {
                self.pokemonDetails = data
            }
        }
    }
    
    func formatHW(value: Int) -> String{
        let doubleValue = Double(value)
        let string = String(format: "%.2f", doubleValue/10)
        
        return string
    }
    
    
}
